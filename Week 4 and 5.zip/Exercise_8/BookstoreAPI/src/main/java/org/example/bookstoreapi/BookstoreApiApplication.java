package org.example.bookstoreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiApplication {

    public static void main(String[] args) {

        System.out.println("Customer class modified in com.example(CRUD).");

        //SpringApplication.run(BookstoreApiApplication.class, args);
    }

}
