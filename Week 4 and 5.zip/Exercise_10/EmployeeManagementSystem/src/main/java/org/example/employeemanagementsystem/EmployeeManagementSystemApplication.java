package org.example.employeemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;




//@SpringBootApplication
@EnableAutoConfiguration
public class EmployeeManagementSystemApplication {
    public static void main(String[] args) {
        System.out.println("pom.xml file modified and hibernate.cfg.xml file added");

        //SpringApplication.run(EmployeeManagementSystemApplication.class, args);
    }


}
