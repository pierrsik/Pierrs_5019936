package com.example;



public class Customer {
    private Long id;
    private String name;
    private String email;

    public void setId(long l) {
        this.id = l;
    }
}
