package org.example.bookstoreapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApiApplication {

    public static void main(String[] args) {

        System.out.println("BookController class modified in com.example, Spring HATEOAS  used.");

        //SpringApplication.run(BookstoreApiApplication.class, args);
    }

}
